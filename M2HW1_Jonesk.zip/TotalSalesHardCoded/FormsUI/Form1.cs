﻿/**
* 1/28/22
* CSC 153
* Kent Jones Jr
* This program will allow users to create an array from a separate text file.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Array Creation
            const int SIZE = 7;     //Array Size
            int index = 0;      //Step through array
            decimal total = 0m; //Accumilator for Sales amount
            //Array to hold sales amounts
            decimal[] sales = new decimal[SIZE];

            //Read contents of the text File
            StreamReader inputFile = File.OpenText("sales.txt"); //Opening File

            //Putting text files sales into Array
            while (!inputFile.EndOfStream && index < sales.Length)
            {
                sales[index] = decimal.Parse(inputFile.ReadLine());
                index++;
            }

            //Display Array
            foreach (decimal val in sales)
            {
                salesListBox.Items.Add(val.ToString("c"));
            }

            //Array Calculations
            foreach (decimal val in sales)
            {
                total += val;
            }
            //Calculation Display
            totalLabel.Text = total.ToString("c");
        }
    }
}