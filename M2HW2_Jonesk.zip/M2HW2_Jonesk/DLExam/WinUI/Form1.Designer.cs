﻿
namespace WinUI
{
    partial class correctAmountTextBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.testListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.passFailLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.correctNumLabel = new System.Windows.Forms.Label();
            this.incorrectNumLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // testListBox
            // 
            this.testListBox.FormattingEnabled = true;
            this.testListBox.ItemHeight = 16;
            this.testListBox.Location = new System.Drawing.Point(4, 0);
            this.testListBox.Margin = new System.Windows.Forms.Padding(4);
            this.testListBox.Name = "testListBox";
            this.testListBox.Size = new System.Drawing.Size(133, 260);
            this.testListBox.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Did you pass?";
            // 
            // passFailLabel
            // 
            this.passFailLabel.AutoSize = true;
            this.passFailLabel.Location = new System.Drawing.Point(145, 34);
            this.passFailLabel.Name = "passFailLabel";
            this.passFailLabel.Size = new System.Drawing.Size(93, 16);
            this.passFailLabel.TabIndex = 4;
            this.passFailLabel.Text = "passFailLabel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(145, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Correct Answers";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(634, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(146, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Incorrect Answers";
            // 
            // correctNumLabel
            // 
            this.correctNumLabel.AutoSize = true;
            this.correctNumLabel.Location = new System.Drawing.Point(149, 120);
            this.correctNumLabel.Name = "correctNumLabel";
            this.correctNumLabel.Size = new System.Drawing.Size(110, 16);
            this.correctNumLabel.TabIndex = 9;
            this.correctNumLabel.Text = "correctNumLabel";
            // 
            // incorrectNumLabel
            // 
            this.incorrectNumLabel.AutoSize = true;
            this.incorrectNumLabel.Location = new System.Drawing.Point(149, 220);
            this.incorrectNumLabel.Name = "incorrectNumLabel";
            this.incorrectNumLabel.Size = new System.Drawing.Size(120, 16);
            this.incorrectNumLabel.TabIndex = 10;
            this.incorrectNumLabel.Text = "incorrectNumLabel";
            // 
            // correctAmountTextBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 262);
            this.Controls.Add(this.incorrectNumLabel);
            this.Controls.Add(this.correctNumLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.passFailLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.testListBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "correctAmountTextBox";
            this.Text = "Driver\'s License Exam";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox testListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label passFailLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label correctNumLabel;
        private System.Windows.Forms.Label incorrectNumLabel;
    }
}

