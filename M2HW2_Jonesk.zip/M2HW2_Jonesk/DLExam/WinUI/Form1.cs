﻿/**
* 2/3/22
* CSC 153
* Kent Jones Jr
* This program will allow users to determine whether they passed or failed their Driver's License Exam.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WinUI
{
    public partial class correctAmountTextBox : Form
    {
        public correctAmountTextBox()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Creating testAnswers Array
            string[] answers = { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
            //Creating userAnswers Array
            string[] userAnswers = new string[20];
            int index = 0;
            int count = 0;
            int questionNum = 0;
            //Creating list for incorrectAnswers
            List<string> incorrectAnswers = new List<string>();
            int wrong = 0;
            //Reading test answers
            StreamReader inputFile = File.OpenText("user1Test.txt");
            while (index <= userAnswers.Length && !inputFile.EndOfStream)
            {
                userAnswers[index] = String.Format(inputFile.ReadLine());

                //Comparing answers
                if (userAnswers[index] == answers[index])
                {
                    count++;
                }
                else
                {
                    questionNum = index + 1;
                    incorrectAnswers.Add(questionNum.ToString());
                    wrong++;
                }
                index++;
            }
            inputFile.Close();

            //Display total correct, incorrect, and incorrect list
            //calculate pass or fail
            if (count >= 15)
            {
                passFailLabel.Text = ("Congratulations! You've passed!");
            }
            else {
                passFailLabel.Text = ("Sorry, you have failed.");
            }
            //displaying incorrect list
            foreach (string str in incorrectAnswers)
            {
                testListBox.Items.Add(str);
            }
            //dipslaying correct
            correctNumLabel.Text = count.ToString();
            //displaying incorrect
            incorrectNumLabel.Text = wrong.ToString();

        }
    }
}
