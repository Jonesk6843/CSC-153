﻿/**
* 2/19/2022
* CSC 153
* Kent Jones Jr
* This program will allow the user to get an array of random numbers of their choice.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generatorButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declaring Variables
                StreamWriter outputFile;
                int userAmount = int.Parse(userNumTextBox.Text.ToString());
                int randomNumber = 0;
                int count = 1;

                //Creating UserFile
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    outputFile = File.CreateText(saveFileDialog1.FileName);

                    Random randomNum = new Random();

                    //Adding userFile Contents
                    while (count <= userAmount && userAmount >= 0)
                    {
                        randomNumber = randomNum.Next(100) + 1;
                        outputFile.WriteLine(randomNumber);
                        count++;
                    }
                    outputFile.Close();
                    //Error if user enters negative number
                    if (userAmount <= -1)
                    {
                        MessageBox.Show("You're input must be a positive integer in order to work!");
                    }
                }
            }
            catch (Exception ex)
            {
                //If user input anything other than the range
                MessageBox.Show("You're input must be an integer.");
            }
        }
    }
}

