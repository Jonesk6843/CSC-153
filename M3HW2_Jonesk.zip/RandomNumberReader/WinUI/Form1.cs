﻿/**
* 2/25/2022
* CSC 153
* Kent Jones Jr
* This program will allow user to open and display numbers.txt file from Random Number generator application.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //Declaring Variables
                StreamReader inputFile;
                int numbers = 0;
                int totalNums = 0;
                int count = 0;

                //Opening userFile
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    inputFile = File.OpenText(openFileDialog1.FileName);

                    //number calculations
                    while (!inputFile.EndOfStream)
                    {
                        numbers = int.Parse(inputFile.ReadLine());
                        count = count + 1;
                        totalNums = numbers + totalNums;
                        listBox1.Items.Add(numbers);
                    }
                    //Calculation Display
                    totalNumLabel.Text = totalNums.ToString();
                    numAmountLabel.Text = count.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}