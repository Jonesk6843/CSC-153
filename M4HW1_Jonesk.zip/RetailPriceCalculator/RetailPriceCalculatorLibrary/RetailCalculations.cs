﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceCalculatorLibrary
{
    public static class RetailCalculations
    {
        public static double CalculateRetail(double wholesale, double markup)
        {
            //Declare variables
            double markupPercent = markup / 100;
            double retailPrice;

            //retailPrice Calculations
            retailPrice = wholesale + (wholesale * markupPercent);

            //return total
            return retailPrice;
        }
    }
}
