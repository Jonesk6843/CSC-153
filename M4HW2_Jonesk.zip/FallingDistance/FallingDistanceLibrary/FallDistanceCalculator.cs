﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingDistanceLibrary
{
    public class FallDistanceCalculator
    {
        public static double fallingDistance(double t)
        {
            //Declare variables
            double fallDistance;
            double g = 9.8;

            //fall distance calculation
            fallDistance = 12 * g * Math.Pow(t, 2);

            //Return falldistance
            return fallDistance;
        }
    }
}
