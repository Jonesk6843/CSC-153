﻿/**
* 3/11/22
* CSC 153
* Kent Jones Jr
* This program will allow the user to calculate the fall distance of an object.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingDistanceLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare user variable
                double userTime;

                //Display Calculations.
                if (double.TryParse(fallTimeTextBox.Text, out userTime))
                {
                    double fallDistance;
                    fallDistance = FallDistanceCalculator.fallingDistance(userTime);
                    fallDistanceTextBox.Text = fallDistance.ToString();
                }
                else
                {
                    //Display error message if strings are inputed.
                    MessageBox.Show("Please enter decimal values.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
