﻿/**
* 3/26/2022
* CSC/ 153
* Kent Jones
* This program will allow the user to input and display their pet's name, type, and age.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Creating instance of class
                Pet myPet = new Pet();

                //Get user input
                myPet.Name = nameTextBox.Text;
                myPet.Type = typeTextBox.Text;
                myPet.Age = int.Parse(ageTextBox.Text);

                //Display Info
                petInfoListbox.Items.Add("Pet's name: " + myPet.Name);
                petInfoListbox.Items.Add("Type of pet: " + myPet.Type);
                petInfoListbox.Items.Add("Pet's age: " + myPet.Age);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}

