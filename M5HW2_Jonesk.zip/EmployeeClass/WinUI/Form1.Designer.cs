﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeName1Label = new System.Windows.Forms.Label();
            this.employeeName2Label = new System.Windows.Forms.Label();
            this.employeeName3Label = new System.Windows.Forms.Label();
            this.employee1IdLabel = new System.Windows.Forms.Label();
            this.employee2Idlabel = new System.Windows.Forms.Label();
            this.employee3Idlabel = new System.Windows.Forms.Label();
            this.employee1DepartmentLabel = new System.Windows.Forms.Label();
            this.employee2DepartmentLabel = new System.Windows.Forms.Label();
            this.employee3DepartmentLabel = new System.Windows.Forms.Label();
            this.employee1PositionLabel = new System.Windows.Forms.Label();
            this.employee2PositionLabel = new System.Windows.Forms.Label();
            this.employee3PositionLabel = new System.Windows.Forms.Label();
            this.EmployeeTableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.EmployeeTableLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeName1Label
            // 
            this.employeeName1Label.AutoSize = true;
            this.employeeName1Label.Location = new System.Drawing.Point(3, 46);
            this.employeeName1Label.Name = "employeeName1Label";
            this.employeeName1Label.Size = new System.Drawing.Size(112, 16);
            this.employeeName1Label.TabIndex = 1;
            this.employeeName1Label.Text = "employee1Name";
            // 
            // employeeName2Label
            // 
            this.employeeName2Label.AutoSize = true;
            this.employeeName2Label.Location = new System.Drawing.Point(3, 88);
            this.employeeName2Label.Name = "employeeName2Label";
            this.employeeName2Label.Size = new System.Drawing.Size(112, 16);
            this.employeeName2Label.TabIndex = 2;
            this.employeeName2Label.Text = "employee2Name";
            // 
            // employeeName3Label
            // 
            this.employeeName3Label.AutoSize = true;
            this.employeeName3Label.Location = new System.Drawing.Point(3, 113);
            this.employeeName3Label.Name = "employeeName3Label";
            this.employeeName3Label.Size = new System.Drawing.Size(112, 16);
            this.employeeName3Label.TabIndex = 3;
            this.employeeName3Label.Text = "employee3Name";
            // 
            // employee1IdLabel
            // 
            this.employee1IdLabel.AutoSize = true;
            this.employee1IdLabel.Location = new System.Drawing.Point(158, 46);
            this.employee1IdLabel.Name = "employee1IdLabel";
            this.employee1IdLabel.Size = new System.Drawing.Size(86, 16);
            this.employee1IdLabel.TabIndex = 4;
            this.employee1IdLabel.Text = "employee1Id";
            // 
            // employee2Idlabel
            // 
            this.employee2Idlabel.AutoSize = true;
            this.employee2Idlabel.Location = new System.Drawing.Point(158, 88);
            this.employee2Idlabel.Name = "employee2Idlabel";
            this.employee2Idlabel.Size = new System.Drawing.Size(86, 16);
            this.employee2Idlabel.TabIndex = 5;
            this.employee2Idlabel.Text = "employee2Id";
            // 
            // employee3Idlabel
            // 
            this.employee3Idlabel.AutoSize = true;
            this.employee3Idlabel.Location = new System.Drawing.Point(158, 113);
            this.employee3Idlabel.Name = "employee3Idlabel";
            this.employee3Idlabel.Size = new System.Drawing.Size(86, 16);
            this.employee3Idlabel.TabIndex = 6;
            this.employee3Idlabel.Text = "employee3Id";
            // 
            // employee1DepartmentLabel
            // 
            this.employee1DepartmentLabel.AutoSize = true;
            this.employee1DepartmentLabel.Location = new System.Drawing.Point(313, 46);
            this.employee1DepartmentLabel.Name = "employee1DepartmentLabel";
            this.employee1DepartmentLabel.Size = new System.Drawing.Size(145, 16);
            this.employee1DepartmentLabel.TabIndex = 7;
            this.employee1DepartmentLabel.Text = "employee1Department";
            // 
            // employee2DepartmentLabel
            // 
            this.employee2DepartmentLabel.AutoSize = true;
            this.employee2DepartmentLabel.Location = new System.Drawing.Point(313, 88);
            this.employee2DepartmentLabel.Name = "employee2DepartmentLabel";
            this.employee2DepartmentLabel.Size = new System.Drawing.Size(145, 16);
            this.employee2DepartmentLabel.TabIndex = 8;
            this.employee2DepartmentLabel.Text = "employee2Department";
            // 
            // employee3DepartmentLabel
            // 
            this.employee3DepartmentLabel.AutoSize = true;
            this.employee3DepartmentLabel.Location = new System.Drawing.Point(313, 113);
            this.employee3DepartmentLabel.Name = "employee3DepartmentLabel";
            this.employee3DepartmentLabel.Size = new System.Drawing.Size(145, 16);
            this.employee3DepartmentLabel.TabIndex = 9;
            this.employee3DepartmentLabel.Text = "employee3Department";
            // 
            // employee1PositionLabel
            // 
            this.employee1PositionLabel.AutoSize = true;
            this.employee1PositionLabel.Location = new System.Drawing.Point(509, 46);
            this.employee1PositionLabel.Name = "employee1PositionLabel";
            this.employee1PositionLabel.Size = new System.Drawing.Size(122, 16);
            this.employee1PositionLabel.TabIndex = 10;
            this.employee1PositionLabel.Text = "employee1position";
            // 
            // employee2PositionLabel
            // 
            this.employee2PositionLabel.AutoSize = true;
            this.employee2PositionLabel.Location = new System.Drawing.Point(509, 88);
            this.employee2PositionLabel.Name = "employee2PositionLabel";
            this.employee2PositionLabel.Size = new System.Drawing.Size(123, 16);
            this.employee2PositionLabel.TabIndex = 11;
            this.employee2PositionLabel.Text = "employee2Position";
            // 
            // employee3PositionLabel
            // 
            this.employee3PositionLabel.AutoSize = true;
            this.employee3PositionLabel.Location = new System.Drawing.Point(509, 113);
            this.employee3PositionLabel.Name = "employee3PositionLabel";
            this.employee3PositionLabel.Size = new System.Drawing.Size(123, 16);
            this.employee3PositionLabel.TabIndex = 12;
            this.employee3PositionLabel.Text = "employee3Position";
            // 
            // EmployeeTableLayout
            // 
            this.EmployeeTableLayout.ColumnCount = 4;
            this.EmployeeTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.EmployeeTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.EmployeeTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 196F));
            this.EmployeeTableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 253F));
            this.EmployeeTableLayout.Controls.Add(this.employee3PositionLabel, 3, 3);
            this.EmployeeTableLayout.Controls.Add(this.employeeName2Label, 0, 2);
            this.EmployeeTableLayout.Controls.Add(this.employee3DepartmentLabel, 2, 3);
            this.EmployeeTableLayout.Controls.Add(this.employee2PositionLabel, 3, 2);
            this.EmployeeTableLayout.Controls.Add(this.employeeName1Label, 0, 1);
            this.EmployeeTableLayout.Controls.Add(this.employee1PositionLabel, 3, 1);
            this.EmployeeTableLayout.Controls.Add(this.employee1IdLabel, 1, 1);
            this.EmployeeTableLayout.Controls.Add(this.employee2Idlabel, 1, 2);
            this.EmployeeTableLayout.Controls.Add(this.employee2DepartmentLabel, 2, 2);
            this.EmployeeTableLayout.Controls.Add(this.employee3Idlabel, 1, 3);
            this.EmployeeTableLayout.Controls.Add(this.employee1DepartmentLabel, 2, 1);
            this.EmployeeTableLayout.Controls.Add(this.employeeName3Label, 0, 3);
            this.EmployeeTableLayout.Controls.Add(this.label1, 0, 0);
            this.EmployeeTableLayout.Controls.Add(this.label2, 1, 0);
            this.EmployeeTableLayout.Controls.Add(this.label3, 2, 0);
            this.EmployeeTableLayout.Controls.Add(this.label4, 3, 0);
            this.EmployeeTableLayout.Location = new System.Drawing.Point(15, 13);
            this.EmployeeTableLayout.Name = "EmployeeTableLayout";
            this.EmployeeTableLayout.RowCount = 4;
            this.EmployeeTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.52525F));
            this.EmployeeTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.47475F));
            this.EmployeeTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.EmployeeTableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.EmployeeTableLayout.Size = new System.Drawing.Size(759, 164);
            this.EmployeeTableLayout.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(158, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "ID Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(313, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Department";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(509, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Position";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 187);
            this.Controls.Add(this.EmployeeTableLayout);
            this.Name = "Form1";
            this.Text = "Employee Table";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.EmployeeTableLayout.ResumeLayout(false);
            this.EmployeeTableLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label employeeName1Label;
        private System.Windows.Forms.Label employeeName2Label;
        private System.Windows.Forms.Label employeeName3Label;
        private System.Windows.Forms.Label employee1IdLabel;
        private System.Windows.Forms.Label employee2Idlabel;
        private System.Windows.Forms.Label employee3Idlabel;
        private System.Windows.Forms.Label employee1DepartmentLabel;
        private System.Windows.Forms.Label employee2DepartmentLabel;
        private System.Windows.Forms.Label employee3DepartmentLabel;
        private System.Windows.Forms.Label employee1PositionLabel;
        private System.Windows.Forms.Label employee2PositionLabel;
        private System.Windows.Forms.Label employee3PositionLabel;
        private System.Windows.Forms.TableLayoutPanel EmployeeTableLayout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

