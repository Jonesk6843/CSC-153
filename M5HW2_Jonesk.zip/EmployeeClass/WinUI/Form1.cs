﻿/**
* 4/8/2022
* CSC 153
* Kent Jones Jr
* This program holds the personal data of three employees in objects.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinUILibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Creating employee objects
            Employee employee1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            Employee employee2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
            Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing","Engineer");

            //Displaying Employee information

            //Employee1
            employeeName1Label.Text = employee1.Name;
            employee1IdLabel.Text = employee1.IdNumber.ToString();
            employee1DepartmentLabel.Text = employee1.Department;
            employee1PositionLabel.Text = employee1.Position;
            
            //Employee 2
            employeeName2Label.Text = employee2.Name;
            employee2Idlabel.Text = employee2.IdNumber.ToString();
            employee2DepartmentLabel.Text = employee2.Department;
            employee2PositionLabel.Text = employee2.Position;
            //Employee 3
            employeeName3Label.Text = employee1.Name;
            employee3Idlabel.Text = employee1.IdNumber.ToString();
            employee3DepartmentLabel.Text = employee3.Department;
            employee3PositionLabel.Text = employee3.Position;
        }
    }
}
