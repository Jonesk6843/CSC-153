﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerClassesLibrary
{
    public class Person
    {
        //Fields
        private string _name;
        private string _address;
        private int _telephone;


        //constructor
        public Person()
        {
            _name = "";
            _address = "";
            _telephone = 0;
        }

        public Person(string name, string address, int telephone)
        {
            _name = name;
            _address = address;
            _telephone = telephone;
        }

        //properties
        public string Name { get; set; }
        public string Address { get; set; }
        public int Telephone { get; set; }
    }
}
