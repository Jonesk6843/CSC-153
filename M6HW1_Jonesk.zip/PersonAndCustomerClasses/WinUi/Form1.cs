﻿/**
* 4/29/21
* CSC 153
* Kent Jones Jr
* This program allows the user to input their information and display it.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonAndCustomerClassesLibrary;

namespace WinUi
{
    public partial class Form1 : Form
    {
        //Create employee object
        Customer customer = new Customer();
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assigning inputs
                customer.Name = nameTextBox.Text;
                customer.Address = addressTextbox.Text;
                customer.Telephone = int.Parse(telephoneTextbox.Text);
                customer.CustomerNumber = int.Parse(customerNumtextBox.Text);

                //Diplaying inputs
                personInfoListbox.Items.Add("User Name: " + customer.Name);
                personInfoListbox.Items.Add("Address: " + customer.Address);
                personInfoListbox.Items.Add("telephone #: " + customer.Telephone);
                personInfoListbox.Items.Add("Customer Number: " + customer.CustomerNumber);
                personInfoListbox.Items.Add("Add to mail list?: " + customer.mailList);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void mailListRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (mailListRadioButton.Checked)
            {
                customer.mailList = bool.Parse("True");
            }
        }
    }
}
