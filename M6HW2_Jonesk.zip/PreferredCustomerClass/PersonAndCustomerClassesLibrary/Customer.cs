﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class Customer : Person
    {
        //Fields
        private int _customerNum;
        private bool _mailList;


        //constructor
        public Customer()
        {
            _customerNum = 0;
            _mailList = true;
        }

        public Customer(int customerNum, bool mailList)
        {
            _customerNum = customerNum;
            _mailList = mailList;
        }
        public int CustomerNumber { get; set; }
        public bool mailList { get; set; }
    }
}
