﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class PreferredCustomer : Customer
    {
        //Fields
        private double _purchaseTotal;
        private decimal _customerDiscount;


        //constructor
        public PreferredCustomer()
        {
            _purchaseTotal = 0;
            _customerDiscount = 0;
        }

        public PreferredCustomer(double purchaseTotal, decimal customerDiscount)
        {
            _purchaseTotal = purchaseTotal;
            _customerDiscount = customerDiscount;
        }
        public double purchaseTotal { get; set; }
        public decimal customerDiscount { get; set; }
    }
}