﻿namespace WinUi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.displayButton = new System.Windows.Forms.Button();
            this.personInfoListbox = new System.Windows.Forms.ListBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.addressTextbox = new System.Windows.Forms.TextBox();
            this.mailListRadioButton = new System.Windows.Forms.RadioButton();
            this.telephoneTextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.customerNumtextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.purchaseTotalTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Address:";
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(134, 213);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(94, 23);
            this.displayButton.TabIndex = 4;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // personInfoListbox
            // 
            this.personInfoListbox.FormattingEnabled = true;
            this.personInfoListbox.ItemHeight = 16;
            this.personInfoListbox.Location = new System.Drawing.Point(16, 242);
            this.personInfoListbox.Name = "personInfoListbox";
            this.personInfoListbox.Size = new System.Drawing.Size(316, 148);
            this.personInfoListbox.TabIndex = 5;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(62, 10);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(177, 22);
            this.nameTextBox.TabIndex = 6;
            // 
            // addressTextbox
            // 
            this.addressTextbox.Location = new System.Drawing.Point(75, 38);
            this.addressTextbox.Name = "addressTextbox";
            this.addressTextbox.Size = new System.Drawing.Size(177, 22);
            this.addressTextbox.TabIndex = 7;
            // 
            // mailListRadioButton
            // 
            this.mailListRadioButton.AutoSize = true;
            this.mailListRadioButton.Location = new System.Drawing.Point(81, 187);
            this.mailListRadioButton.Name = "mailListRadioButton";
            this.mailListRadioButton.Size = new System.Drawing.Size(174, 20);
            this.mailListRadioButton.TabIndex = 9;
            this.mailListRadioButton.TabStop = true;
            this.mailListRadioButton.Text = "Don\'t Add me to Mail List";
            this.mailListRadioButton.UseVisualStyleBackColor = true;
            this.mailListRadioButton.CheckedChanged += new System.EventHandler(this.mailListRadioButton_CheckedChanged);
            // 
            // telephoneTextbox
            // 
            this.telephoneTextbox.Location = new System.Drawing.Point(140, 70);
            this.telephoneTextbox.Name = "telephoneTextbox";
            this.telephoneTextbox.Size = new System.Drawing.Size(177, 22);
            this.telephoneTextbox.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Telephone Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "Customer Number:";
            // 
            // customerNumtextBox
            // 
            this.customerNumtextBox.Location = new System.Drawing.Point(131, 98);
            this.customerNumtextBox.Name = "customerNumtextBox";
            this.customerNumtextBox.Size = new System.Drawing.Size(177, 22);
            this.customerNumtextBox.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Your Purchase Total: ";
            // 
            // purchaseTotalTextBox
            // 
            this.purchaseTotalTextBox.Location = new System.Drawing.Point(154, 140);
            this.purchaseTotalTextBox.Name = "purchaseTotalTextBox";
            this.purchaseTotalTextBox.Size = new System.Drawing.Size(177, 22);
            this.purchaseTotalTextBox.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 402);
            this.Controls.Add(this.purchaseTotalTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.customerNumtextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.telephoneTextbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.mailListRadioButton);
            this.Controls.Add(this.addressTextbox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.personInfoListbox);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Person and Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.ListBox personInfoListbox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox addressTextbox;
        private System.Windows.Forms.RadioButton mailListRadioButton;
        private System.Windows.Forms.TextBox telephoneTextbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox customerNumtextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox purchaseTotalTextBox;
    }
}

