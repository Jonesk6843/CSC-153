﻿/**
* 4/29/21
* CSC 153
* Kent Jones Jr
* This program allows the user to input their information and display it. It also allow the user to determine their future discount purchase.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PreferredCustomerClassLibrary;

namespace WinUi
{
    public partial class Form1 : Form
    {
        //Create customer object
        Customer customer = new Customer();
        PreferredCustomer preferredCustomer = new PreferredCustomer();
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assigning inputs
                customer.Name = nameTextBox.Text;
                customer.Address = addressTextbox.Text;
                customer.Telephone = int.Parse(telephoneTextbox.Text);
                customer.CustomerNumber = int.Parse(customerNumtextBox.Text);
                preferredCustomer.purchaseTotal = double.Parse(purchaseTotalTextBox.Text);

                //Diplaying inputs
                personInfoListbox.Items.Add("User Name: " + customer.Name);
                personInfoListbox.Items.Add("Address: " + customer.Address);
                personInfoListbox.Items.Add("telephone #: " + customer.Telephone);
                personInfoListbox.Items.Add("Customer Number: " + customer.CustomerNumber);
                personInfoListbox.Items.Add("Add to mail list?: " + customer.mailList);
                personInfoListbox.Items.Add("Purchase Total: " + preferredCustomer.purchaseTotal.ToString("c"));
                personInfoListbox.Items.Add("Future Purchase Discout Total: " + preferredCustomer.customerDiscount.ToString("p"));

                //Creating if loop for each discount
                if (preferredCustomer.purchaseTotal >= 2000)
                {
                    preferredCustomer.customerDiscount = 0.10m;
                }
                else if (preferredCustomer.purchaseTotal >= 1500)
                {
                    preferredCustomer.customerDiscount = 0.07m;
                }
                else if (preferredCustomer.purchaseTotal >= 1000)
                {
                    preferredCustomer.customerDiscount = 0.06m;
                }
                else if (preferredCustomer.purchaseTotal >= 500)
                {
                    preferredCustomer.customerDiscount = 0.05m;
                }
                else
                {
                    preferredCustomer.customerDiscount = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void mailListRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (mailListRadioButton.Checked)
            {
                customer.mailList = bool.Parse("True");
            }
        }
    }
}
